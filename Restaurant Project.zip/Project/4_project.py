from item_class import items
from prettytable import PrettyTable
from project_exception import *


print('''Please confirm your identity-
1)Admin
2)Customer''')
try:
    user=int(input("Please enter number from above menu as per your identity: "))
except ValueError as v:
    print(v)
class Restaurant():
    
    def __init__(self):
        self.menu_items=[]

    def show_menu(self):
        table=PrettyTable()
        print("-"*40)
        print("         🍴😋 Indian Restraurant 🍴😋   ")
        print("-"*40)
        table.field_names=["ID","Name","Price"]
        with open("item.txt","r") as fp:
            for i in fp:
                d=i.split(",")
                
                table.add_row([d[0],d[1],d[2]])
            print(table)

    def add_item(self): 
        try:
            num=int(input("Please enter how many items are there 🤔🤔: "))
            for i in range(num):
                try:
                    id=int(input("Please Enter ID of an item: "))
                except ValueError:
                    print("Sorry!😥😥 This is an invalid ID")
                    break
                else:
                    with open("item.txt","r") as fp:
                        for j in fp:
                            k=j.split(",")
                            int_id=int(k[0])
                            try:
                                if int_id==(id):
                                    raise duplicate_id_error
                            except duplicate_id_error as d:
                                print(d)
                                break
                                
                            
                        else:  
                                with open("item.txt","a") as fp:
                                    item_name=input("Please Enter Item name: ")
                                    price=int(input("Please Enter price of one item: "))
                                    data=(items(id,item_name,price))
                                    fp.write(str(data))
                                    print("Data Saved👍👍👍👍....")
                                    
            
        except ValueError as v:
            print("Sorry!😥😥 This is an invalid number...")      
    def update_item(self):
        self.menu_items.clear()
        print('''What do you want to update: 
                     1)ID
                     2)Name
                     3)Price''')
        try:
            ch=int(input("Please Enter your choice here: "))
            if ch==1:
                data=[]
                found=False
                try:
                   old_id=int(input("Please enter Item ID that you want to update: "))
                except ValueError as v:
                    print(f"Sorry!😣😣 This is an invalid ID.....")
                    
                else:
                    with open ("item.txt","r") as fp:
                        for x in fp:
                            a=x.split(",")
                            
                            if a[0]==str(old_id):
                                found=True
                                try:
                                   new_id=int(input("Please enter new ID for that Item: "))
                                except ValueError as v:
                                    print(f"Sorry!😣😣 This is an invalid ID.....")
                                    break
                                else:
                                    flag=False
                                    with open ("item.txt","r") as fp:
                                        for x in fp:
                                            a=x.split(",")
                                            try:
                                                if a[0]==str(new_id):

                                                  flag=True
                                                  raise duplicate_id_error
                                                  break
                                                  
                                            except duplicate_id_error as d:
                                                print(d)
                                                
                                        else:
                                            with open("item.txt","r") as fp:
                                                for x in fp:
                                                    b=x.split(",")
                                                    if b[0]==str(old_id):
                                                        #with open("item.txt","w") as fp:
                                                            id=str(new_id)
                                                            item_name=b[1]
                                                            price=b[2]
                                                            new_data=items(id,item_name,price)
                                                            data.append(str(new_data))

                                                    else:
                                                        data.append(x)
                                
                            else:
                                continue            
                    
                            if flag==False:
                                 with open("item.txt","w")as fp:
                                  for i in data:
                                     fp.write(str(i))
                                
                                  print("Data Updated succesfully👍👍......")
                        else:
                            try:
                                if found==False:
                                    
                                    raise invalid_id_error
                            except invalid_id_error as i:
                                print(i)
            elif ch==2:
             data=[]
             found=False
             try:
               old_id=int(input("Please enter Item ID that you want to update: "))
             except ValueError as v:
                print(f"Sorry!😣😣 This is an invalid ID.....")
                
             else:
                with open ("item.txt","r") as fp:
                    for x in fp:
                        a=x.split(",")
                        
                        if a[0]==str(old_id):
                            found=True
                            new_name=(input("Please enter new name for that Item: "))
                            with open ("item.txt","r") as fp:
                                for x in fp:
                                    a=x.split(",")
                                    if a[0]==str(old_id):
                                        found=True
                                        id=str(a[0])
                                        item_name=new_name
                                        price=a[2]
                                        new_data=items(id,item_name,price)
                                        data.append(str(new_data))    
                                    else:
                                            data.append(x)
                        else:
                            continue      
     
                    if found==True:
                         with open("item.txt","w")as fp:
                            for i in data:
                                fp.write(str(i))
                            
                            print("Data Updated succesfully👍👍......")
                    else:
                        try:
                            if found==False:
                                raise invalid_id_error
                        except invalid_id_error as i:
                            print(i)
                
            elif ch==3:
                data=[]
                found=False
                try:
                 old_id=int(input("Please enter Item ID that you want to update: "))
                except ValueError as v:
                    print(f"Sorry!😣😣 This is an invalid ID.....")
                    
                else:
                    with open ("item.txt","r") as fp:
                        for x in fp:
                            a=x.split(",")
                            
                            if a[0]==str(old_id):
                                found=True
                                try:
                                 new_price=int(input("Please enter new price for that Item: "))
                                 
                                except ValueError :
                                     print(f"Sorry😣😣 This price is not acceptable.Price must be numeric....")
                                     break
                                     
                                else:
                                    #flag=False
                                    with open ("item.txt","r") as fp:
                                        for x in fp:
                                            a=x.split(",")
                                        
                                            if a[0]==str(old_id):
                                                id=(a[0])
                                                item_name=a[1]
                                                price=new_price
                                                new_data=items(id,item_name,price)
                                                data.append(str(new_data))    
                                            else:
                                                data.append(x)
                                
                            else:
                                continue            
                        else:
                            if found==True:
                                with open("item.txt","w")as fp:
                                    for i in data:
                                        fp.write(str(i))
                                    
                                    print("Data Updated succesfully👍👍......")
                            else:
                                try:
                                    if found==False:  
                                        raise invalid_id_error
                                except invalid_id_error as i:
            
                                        print(i)    
            elif ch not in(1,2,3):
                try:
                    raise invalid_choice_error
                except invalid_choice_error as c:            
                    print(c)
        except ValueError :
            print(f"Sorry!😣😣 This is an invalid choice......")
            
        

    def delete_item(self,id):
        with open("item.txt","r") as fp:
                data=[]
                found=False
                for x in fp:
                   
                    a=x.split(",")
                    if a[0]==str(id):
                        found=True
                        continue
                        
                    else:
                        data.append(x)
                if found==True:
                            with open ("item.txt","w") as fp:
                                for i in data:
                                    fp.write((i))
                            print("Data Deleted succesfully👍👍....")
                else:
                    try:
                        raise invalid_id_error
                    except invalid_id_error as d:
                        print(d)
                           # print("There is no item with ID",id)
    def search_by_name(self):
        
            item_name=input("Please enter item name that you want to search: ")
            l_name=item_name.lower()
            
        
            with open ("item.txt","r") as fp:
                for x in fp:
                    (y)=x.split(",")
                    
                    z=(y[1]).lower()
                    if z==item_name.lower():
                        Table=PrettyTable()
                        Table.field_names=["ID","Name","Price"]
                        Table.add_row([y[0],y[1],y[2]])
                        print(Table)

                        #print(x)
                        break
                    else:
                        continue
                        
                else:
                    print(f"Sorry!😣 {item_name} is not available at this moment")
                    print("You can try something else")

                
if user==1:
    if __name__=="__main__":
        while True:    
            with open ("3_admin_password.txt","r") as fp:
                password=input("Please enter your password here: ")
                for i in fp:
                    if i==password:
                        print("Login Succesfull....")
                        Restro=Restaurant()
                        print("-"*30)
                        print("  🍴😋 Indian Restaurant 🍴😋")
                        print("-"*30)
                        while True:
                            print('''             
            1)Show menu
            2)Add Item
            3)Update Item
            4)Delete Item
            5)Search item by name
            6)Exit''')
                            print("-"*30)
                            try:
                                choice=int(input("What do you want perform today: "))
                            except ValueError as v:
                                print("Sorry!😣😣 This is an invalid choice.Please enter valid choice...")
                            else:
                                if choice==1:
                                    Restro.show_menu()

                                elif choice==2:
                                    Restro.add_item()
                                
                                elif choice==3:
                                    Restro.update_item()
 
                                elif choice==4:
                                    id=input("Please enter ID of an item that you want to delete: ")
                                    Restro.delete_item(id)
                                
                                elif choice==5:
                                    Restro.search_by_name()
                                else:
                                    print("Thank you!")
                                    break
                        
                
                    else:
                        print("Please provide valid password.")
                break
class restaurant():
    gst=1.18
    def __init__(self):
        self.menu_items=[]

    def show_menu(self):
        table=PrettyTable()
        print("-"*40)
        print("      🍴😋 Indian Restraurant🍴😋    ")   
        print("-"*40)
        table.field_names=["ID","Name","Price"]
        #print("   ID\t   ","    NAME\t   ","   PRICE\t   ")
        with open("item.txt","r") as fp:
            for i in fp:
                d=i.split(",")
                
                table.add_row([d[0],d[1],d[2]])
            print(table)

    def order_item_by_id(self):
        p_table=PrettyTable()
        price=[]
        
        # amt=0
        # p_table.field_names=["ID","Name","Price","Quantity"]
        total_amt=0
        p_table.field_names=["ID","Name","Price","Quantity","Total"]
        while True:
            bill=0
            amt=0
            try:  
                item_id=int(input("Please enter item Id that you want to order: "))
            

                with open("item.txt","r") as fp:
                        
                        for x in fp:
                            
                            a=x.split(",")
                            if a[0]==str(item_id):
                                #print(x)
                                try:
                                    
                                    quantity=int(input("Please enter quantity of your item: "))
                                    
                                except ValueError :
                                    print(f"Sorry!😣😣 This is an invalid quantity.Quantity must be integer......")
                                    break
                                else:
                                    price.append(a[2])
                                    y=int(a[2])

                                    # amt+=(y*quantity)
                                    # p_table.add_row([a[0],a[1],a[2],quantity])
                                    # break
                                    amt+=(y*quantity)
                                    bill+=amt
                                    
                                    
                                    p_table.add_row([a[0],a[1],a[2],quantity,amt])
                                    break
                                
                        else:
                            try:
                                raise invalid_id_error
                            except invalid_id_error as i:
                                print(i)
                            #print(f"Sorry! There is no item with {item_id} ID")
                
            except ValueError as v:
                print("Sorry!😣😣 This is an invalid id.ID must be integer......")
            
            else:
                
                    # msg=(input("Do you want to continue your order(Yes/No)?: "))
                    
                
                    # if msg.lower()!="yes"  :
                    #     print(p_table)
                    #     self.pay_bill(amt)
                    #     break
                    msg=input("Do you want to continue your order(Yes/No)?: ")
                    total_amt+=amt
                    if msg.lower()!="yes":
                        print(p_table)
                        self.pay_bill(total_amt)
                        break
                    
    def order_item_by_name(self):
    
        p_table=PrettyTable()
        price=[]
        

        total_amt=0
        p_table.field_names=["ID","Name","Price","Quantity","Total"]
        while True:
                bill=0
                amt=0
              
                item_name=(input("Please enter item name that you want to order: "))
                with open("item.txt","r") as fp:
                        
                        for x in fp:
                            
                            a=x.split(",")
                            
                            l_name=a[1].lower()
                            if l_name==item_name.lower():
                                    
                                    quantity=int(input("Please enter quantity of your item: "))
                                
                                    price.append(a[2])
                                    y=int(a[2])

                                    amt+=(y*quantity)
                                    bill+=amt
                                    
                                    
                                    p_table.add_row([a[0],a[1],a[2],quantity,amt])
                                    break
                                
                        else:
                            try:
                                raise invalid_item_error
                            except invalid_item_error as i:
                                print(i)
                msg=input("Do you want to continue your order(Yes/No)?: ")
                total_amt+=amt
                if msg.lower()!="yes":
                    print(p_table)
                    self.pay_bill(total_amt)
                    break
    
    
    def search_item_by_name(self):
        
            item_name=input("Please enter item name that you want to search: ")
            l_name=item_name.lower()
            with open ("item.txt","r") as fp:
                for x in fp:
                    (y)=x.split(",")
                    
                    z=(y[1]).lower()
                    if z==item_name.lower():
                        Table=PrettyTable()
                        Table.field_names=["ID","Name","Price"]
                        Table.add_row([y[0],y[1],y[2]])
                        print(Table)
                        break
                    else:
                        continue
                        
                else:
                    try:
                        raise invalid_item_error
                    except invalid_item_error as x:
                        print(x)

    def pay_bill(self,Total):
        gst_bill=Total*restaurant.gst

        print("*"*50)
        print(f"Your Total Bill is💵💵:   RS {Total} ")
        print(f"GST=18%")
        print(f"Your Total Bill with 18% GST is💵💵:   RS {int(gst_bill)} ")
        print("*"*50)
        
        while True:
            try:
                if Total>0:
                       User_amt=int(input("Please pay above mentioned bill amount: "))
                else:
                    break
            except ValueError as v:
                print("Sorry!😣😣 Please provide valid amount")
            else:
                gst_bill=int(gst_bill)
                if gst_bill==User_amt and gst_bill>0:
                    print('''Hey Thanks🙏🙏  
For Your Purchase !
                    You have brought a
                    big smile to our bussiness🤗🤗.
                    Come Again Soon...........''')
                    break
                elif User_amt>gst_bill:
                    print("Sorry!😥Your amount is exceeding the bill amount")
                elif User_amt<gst_bill:
                    print("Sorry!😥You have provided the amount less than actual bill amount")
    def add_rating(self):
        try:
            rating=int(input("Please provide the overall rating: "))
        except ValueError as v:
            print("Sorry!😥😥 Rating must be an integer value")
        else:

            if rating in (1,2,3,4,5):
                if rating==1:
                    
                    rating_num="⭐"*1
                    print(f'''Thanks 🙏🙏 for sharing your {rating_num} rating with us.😞😞''')

                elif rating==2:
                    rating_num="⭐"*2
                    print(f"Thanks 🙏🙏  for sharing your {rating_num} rating with us.😥😥")

                elif rating==3:
                    rating_num="⭐"*3
                    print(f"Thanks🙏🙏 for sharing your {rating_num} rating with us.🫡🫡")
                    

                elif rating==4:
                    rating_num="⭐"*4
                    print(f"Thanks🙏🙏 for sharing your {rating_num} rating with us.🤩🤩")

                elif rating==5:
                    rating_num="⭐"*5
                    print(f"Thanks🙏🙏 for sharing your {rating_num} rating with us.🤩🤩")

            else:
                print("Invalid Rating.Please provide rating out of 5")
                

if user==2:
    
    Restro=restaurant()
    print("-"*30)
    print("  🍴😋 Indian Restaurant🍴😋")
    print("-"*30)
    while True:
        print('''             
        1)Show menu
        2)Order Item by id
        3)Order Item by name
        4)Search item by name
        5)Add Rating
        6)Exit''')
            
        print("-"*30)
        try:
            choice=int(input("What do you want try today: "))
        except ValueError as v:
            print(v)
        else:

            if choice==1:
                Restro.show_menu()
            elif choice==2:
                Restro.order_item_by_id()
    
            
            elif choice==3:
                
                Restro.order_item_by_name()

            elif choice==4:
                Restro.search_item_by_name()
            
            elif choice==5:
                Restro.add_rating()
            else:
                print("Thank you!")
                break
