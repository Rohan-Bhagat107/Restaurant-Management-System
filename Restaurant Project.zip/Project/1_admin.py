from item_class import items
from prettytable import PrettyTable
from admin_exceptions import *

class Restaurant():
    
    def __init__(self):
        self.menu_items=[]     

    def show_menu(self):
        table=PrettyTable()         #to display the menu in a structured format
        print("-"*40)
        print("         🍴😋 Indian Restraurant 🍴😋   ")
        print("-"*40)
        table.field_names=["ID","Name","Price"]
        #print("   ID\t   ","    NAME\t   ","   PRICE\t   ")
        with open("item.txt","r") as fp:
            for i in fp:
                d=i.split(",")
                
                table.add_row([d[0],d[1],d[2]])        # adding rowise data in the table
            print(table)

    def add_item(self):
        
        
        try:
            num=int(input("How many items are there 🤔🤔: "))
            for i in range(num):
                try:
                    id=int(input("Enter ID of an item: "))
                except ValueError as v:
                    print(v)
                else:
                    with open("item.txt","r") as fp:
                        for j in fp:
                            k=j.split(",")
                            int_id=int(k[0])
                            if int_id==(id):             # Checking for unique ID
                                print("Sorry😥😥This ID is already exists")
                                break
                        else:
                            with open("item.txt","a") as fp:         # appneding the data 
                                item_name=input("Enter Item name: ")
                                price=int(input("Enter price of one item: "))
                                data=(items(id,item_name,price))
                                fp.write(str(data))
                                print("Data Saved👍👍👍👍....") 
            
        except ValueError as v:
            print(v)
       
          
    def update_item(self):
        self.menu_items.clear()
        print('''What do you want to update: 
                     1)ID
                     2)Name
                     3)Price''')
        
        ch=int(input("Enter your choice here: "))
        if ch==1:
            data=[]
            found=False
            try:
               old_id=int(input("Enter Item ID that you want to update: "))
            except ValueError as v:
                print(v)
            else:
                with open ("item.txt","r") as fp:
                    for x in fp:
                        a=x.split(",")
                        
                        if a[0]==str(old_id):
                            found=True
                            try:
                              new_id=int(input("Enter new ID for that Item: "))
                            except ValueError as v:
                                print(v)
                            else:
                                flag=False
                                with open ("item.txt","r") as fp:
                                    for x in fp:
                                        a=x.split(",")
                                        try:
                                            if a[0]==str(new_id):

                                             flag=True
                                             break
                                             raise duplicate_id_error
                                        except duplicate_id_error as d:
                                            print(d)
                                             
                                    else:
                                        with open("item.txt","r") as fp:
                                            for x in fp:
                                                b=x.split(",")
                                                if b[0]==str(old_id):
                                                    #with open("item.txt","w") as fp:
                                                        id=str(new_id)
                                                        item_name=b[1]
                                                        price=b[2]
                                                        new_data=items(id,item_name,price)
                                                        data.append(str(new_data))

                                                else:
                                                    data.append(x)
                            
                        else:
                            continue            
                 
                        if flag==False:
                         with open("item.txt","w")as fp:
                            for i in data:
                                fp.write(str(i))
                            
                            print("Data Updated succesfully👍👍......")
                    else:
                        try:
                            if found==False:
                                
                                raise invalid_id_error
                        except invalid_id_error as i:
                            print(i)
                        
        elif ch==2:
            data=[]
            found=False
            try:
               old_id=int(input("Enter Item ID that you want to update: "))
            except ValueError as v:
                print(v)
            else:
                with open ("item.txt","r") as fp:
                    for x in fp:
                        a=x.split(",")
                        
                        if a[0]==str(old_id):
                            found=True
                            try:
                              new_name=(input("Enter new name for that Item: "))
                            except ValueError as v:
                                print(v)
                            else:
                                flag=False
                                with open ("item.txt","r") as fp:
                                    for x in fp:
                                        a=x.split(",")
                                        if a[0]==str(old_id):
                                            flag=True
                                            id=str(a[0])
                                            item_name=new_name
                                            price=a[2]
                                            new_data=items(id,item_name,price)
                                            data.append(str(new_data))    
                                        else:
                                             data.append(x)
                        else:
                            continue            
                 
                        # if found==True:
                        #  with open("item.txt","w")as fp:
                        #     for i in data:
                        #         fp.write(str(i))
                            
                        #     print("Data Updated succesfully👍👍......")
                        if flag==False:
                         with open("item.txt","w")as fp:
                            for i in data:
                                fp.write(str(i))
                            
                            print("Data Updated succesfully👍👍......")
                    else:
                        try:
                            if found==False:
                                
                                raise invalid_id_error
                        except invalid_id_error as i:
                            print(i)
        
        elif ch==3:
            data=[]
            found=False
            try:
               old_id=int(input("Enter Item ID that you want to update: "))
            except ValueError as v:
                print(v)
            else:
                with open ("item.txt","r") as fp:
                    for x in fp:
                        a=x.split(",")
                        
                        if a[0]==str(old_id):
                            found=True
                            try:
                              new_price=int(input("Enter new price for that Item: "))
                            except ValueError as v:
                                print(v)
                            else:
                                flag=False
                                with open ("item.txt","r") as fp:
                                    for x in fp:
                                        a=x.split(",")
                                    
                                        if a[0]==str(old_id):
                                            id=str(a[0])
                                            item_name=a[1]
                                            price=new_price
                                            new_data=items(id,item_name,price)
                                            data.append(str(new_data))    
                                        else:
                                             data.append(x)
                            
                        else:
                            continue            
                 
                        if falg==False:
                         with open("item.txt","w")as fp:
                            for i in data:
                                fp.write(str(i))
                            
                            print("Data Updated succesfully👍👍......")
                    else:
                        try:
                             if found==False:  
                                raise invalid_id_error
                        except invalid_id_error as i:
                                 print(i)
    def delete_item(self,id):
        with open("item.txt","r") as fp:
                data=[]
                found=False
                for x in fp:
                   
                    a=x.split(",")
                    if a[0]==str(id):
                        found=True
                        continue
                        
                    else:
                        data.append(x)
                if found==True:
                            with open ("item.txt","w") as fp:
                                for i in data:
                                    fp.write((i))
                            print("Data Updated succesfully👍👍....")
                else:
                            print("There is no item with ID",id)
    def search_by_name(self):
        
            item_name=input("Enter item name that you want to search: ")
            l_name=item_name.lower()
            
        # except string_error as st:
        #     print(st)
        #else:
            with open ("item.txt","r") as fp:
                for x in fp:
                    (y)=x.split(",")
                    
                    z=(y[1]).lower()
                    if z==item_name.lower():
                        Table=PrettyTable()
                        Table.field_names=["ID","Name","Price"]
                        Table.add_row([y[0],y[1],y[2]])
                        print(Table)

                        #print(x)
                        break
                    else:
                        continue
                        
                else:
                    print(f"Sorry!😣 {item_name} is not available at this moment")
                    print("You can try something else")

                

if __name__=="__main__":
    while True:    
        with open ("3_admin_password.txt","r") as fp:
            password=input("Enter your password here: ")
            for i in fp:
                if i==password:
                    print("Login Succesfull....")
                    Restro=Restaurant()
                    print("-"*30)
                    print("  🍴😋 Indian Restaurant 🍴😋")
                    print("-"*30)
                    while True:
                        print('''             
        1)Show menu
        2)Add Item
        3)Update Item
        4)Delete Item
        5)Search item by name
        6)Exit''')
                        print("-"*30)
                        try:
                            choice=int(input("What do you want perform today: "))
                        except ValueError as v:
                            print(v)

                        else:

                            if choice==1:
                                Restro.show_menu()

                            elif choice==2:
                                Restro.add_item()
                            
                            elif choice==3:
                                #id=int(input("Enter old_item ID that you want to update: "))
                                res=Restro.update_item()
                                
                            
                            elif choice==4:
                                id=input("Enter ID of an item that you want to delete: ")
                                Restro.delete_item(id)
                            
                            elif choice==5:
                                Restro.search_by_name()
                            else:
                                print("Thank you!")
                                break
                    break
                else:
                    print("Please provide valid password.")
    # # 
# 1,Paneer Tikka,500
# 2,Matar Paneer,410
# 3,Shahi Paneer,370
# 4,Veg Pulav,250
# 5,Dal Makhani,280
# 6,Chicken Biryani,370
# 7,Tandoori Chicken,420
# 8,Chicken Curry,450
# 9,Egg Bhurji,275
# 10,Fish curry,470
# 11,Mutton Fry,570
# 12,Chicken 65,490
# 13,Omlet,175
# 14,Red velvet Cake,230
# 15,Ice Cream,145
# 16,Cookies,135
# 17,Pastries,175
# 18,Chocklet Deep Ice Cream,75
# 19,Rolled Ice cream,125
# 20,Butterscotch Ice cream,135