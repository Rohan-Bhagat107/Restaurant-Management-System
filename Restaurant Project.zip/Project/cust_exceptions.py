class quantity_error(Exception):
    def __str__(self):
        return f"Sorry!😣😣 This is an invalid quantity.Quantity must be integer......"

class choice_error(Exception):
    def __str__(self):
        return f"Sorry!😣😣 This is an invalid choice.Choice must be string......"

class invalid_item_error(Exception):
    def __str__(self):
        return f"Sorry!😣😣 This item is not available at this moment.You can try something else....."

