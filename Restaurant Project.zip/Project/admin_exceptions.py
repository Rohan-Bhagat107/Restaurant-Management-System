class invalid_id_error(Exception):
    def __str__(self):
        return f"Sorry😥😥 There is no item with such id...."

class duplicate_id_error(Exception):
    def __str__(self):
        return f"Sorry😥😥 This ID is already exists...."

class invalid_price_error(Exception):
    def __str__(self):
        return f"Sorry😣😣 This price is not acceptable.Price must be an integer"

class name_error(Exception):
    def __str__(self):
        return f"Sorry!😣😣This ia an Invalid Name. Name must be a string "


