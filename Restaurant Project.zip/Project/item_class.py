class items():
    def __init__(self,id,item_name,price):
        self.id=id
        self.item_name=item_name
        self.price=price
    def __str__(self):
        return f"{self.id},{self.item_name},{self.price}\n"

# id:2 | item:Matar Paneer |price:410
# id:3 | item:Shahi Paneer |price:370
# id:4 | item:Veg Pulav |price:250
# id:5 | item:Dal Makhani |price:280
# id:6 | item:Chicken Biryani |price:370
# id:7 | item:Tandoori Chicken |price:420
# id:8 | item:Chicken Curry |price:450
# id:9 | item:Egg Bhurji |price:275
# id:10 | item:Fish curry |price:470
# id:11 | item:Mutton Fry |price:570
# id:12 | item:Chicken 65 |price:490
# id:13 | item:Omlet |price:175
# id:14 | item:Red velvet Cake |price:230
# id:15 | item:Ice Cream |price:145
# id:16 | item:Cookies |price:135
# id:17 | item:Pastries |price:175
# id:18 | item:Chocklet Deep Ice Cream |price:75
# id:19 | item:Rolled Ice cream |price:125
# id:20 | item:Butterscotch Ice cream |price:135





# 1,Paneer Tikka,500
# 2,Matar Paneer,410
# 3,Shahi Paneer,370
# 4,Veg Pulav,250
# 5,Dal Makhani,289
# 6,Chicken Biryani,370
# 7,Tandoori Chicken,420
# 8,Chicken Curry,450
# 9,Egg Bhurji,275
# 10,Fish curry,470
# 11,Mutton Fry,570
# 12,Chicken 65,490
# 13,Omlet,175
# 14,Red velvet Cake,230
# 15,Ice Cream,145
# 16,Cookies,135
# 17,Pastries,175
# 19,Rolled Ice cream,125
# 20,Butterscotch Ice Cream,136
# 21,Butter Naan,42
# 22,Gulab Jamun,35