from item_class import items
from prettytable import PrettyTable

class Restaurant():
    
    def __init__(self):
        self.menu_items=[]

    def show_menu(self):
        table=PrettyTable()
        print("-"*40)
        print("      🍴😋 INDIAN Restraurant🍴😋    ")  #9 #4  
        print("-"*40)
        table.field_names=["ID","Name","Price"]
        #print("   ID\t   ","    NAME\t   ","   PRICE\t   ")
        with open("item.txt","r") as fp:
            for i in fp:
                d=i.split(",")
                
                table.add_row([d[0],d[1],d[2]])
            print(table)

    def order_item_by_id(self):
        #no=int(input("Enter how many items you want to order: "))
        p_table=PrettyTable()
        price=[]
        amt=0
        p_table.field_names=["ID","Name","Price","Quantity"]
        while True:
            try:  
                item_id=int(input("Enter item Id that you want to order: "))
            

                with open("item.txt","r") as fp:
                        
                        for x in fp:
                            
                            a=x.split(",")
                            if a[0]==str(item_id):
                                #print(x)
                                quantity=int(input("Enter quantity of your item: "))
                                price.append(a[2])
                                y=int(a[2])

                                amt+=(y*quantity)
                                # p_table.field_names=["ID","Name","Price","Quantity"]
                                p_table.add_row([a[0],a[1],a[2],quantity])
                                break
                                
                        else:
                            print(f"Sorry! There is no item with {item_id} ID")
                
            except ValueError as v:
                print(v)
            
            else:
                #print(p_table)
                msg=input("Do you want to continue(Yes/No): ")
                
                if msg.lower()!="yes":
                    print(p_table)
                    self.pay_bill(amt)
                    break
    
    def order_item_by_name(self):
    
        p_table=PrettyTable()
        price=[]
        amt=0
        p_table.field_names=["ID","Name","Price","Quantity"]
        while True:
            try:  
                item_name=(input("Enter item name that you want to order: "))

                with open("item.txt","r") as fp:
                        
                        for x in fp:
                            
                            a=x.split(",")
                            
                            l_name=a[1].lower()
                            if l_name==item_name.lower():
                               
                                quantity=int(input("Enter quantity of your item: "))
                                price.append(a[2])
                                y=int(a[2])

                                amt+=(y*quantity)
                                
                                p_table.add_row([a[0],a[1],a[2],quantity])
                                break
                                
                        else:
                            print(f"Sorry! There is no item with name {item_name} ")
                
            except ValueError as v:
                print(v)
            
            else:
               
                msg=input("Do you want to continue your order(Yes/No): ")
                
                if msg.lower()!="yes":
                    print(p_table)
                    self.pay_bill(amt)
                    break
    
    
    def search_item_by_name(self):
        
            item_name=input("Enter item name that you want to search: ")
            l_name=item_name.lower()
            with open ("item.txt","r") as fp:
                for x in fp:
                    (y)=x.split(",")
                    
                    z=(y[1]).lower()
                    if z==item_name.lower():
                        Table=PrettyTable()
                        Table.field_names=["ID","Name","Price"]
                        Table.add_row([y[0],y[1],y[2]])
                        print(Table)
                        break
                    else:
                        continue
                        
                else:
                    print(f"Sorry! {item_name} is not available at this moment")
                    print("You can try something else")
    def pay_bill(self,amt):
        print("*"*50)
        print(f"Your Total Bill is💵💵:   RS {amt} ")
        print("*"*50)
        
        while True:
            try:
                User_amt=int(input("Please pay above mentioned bill amount: "))
            except ValueError as v:
                print(v)
            else:
                
                if amt==User_amt:
                    print("Thank You!")
                    break
    def add_rating(self):
        try:
            rating=int(input("Please provide the overall rating: "))
        except ValueError as v:
            print(v)
        else:

            if rating in (1,2,3,4,5):
                if rating==1:
                    
                    rating_num="⭐"*1
                    print(f"Thanks 🙏🙏 for sharing your {rating_num} rating with us.😞😞")

                elif rating==2:
                    rating_num="⭐"*2
                    print(f"Thanks 🙏🙏  for sharing your {rating_num} rating with us.😥😥")

                elif rating==3:
                    rating_num="⭐"*3
                    print(f"Thanks🙏🙏 for sharing your {rating_num} rating with us.🫡🫡")
                    

                elif rating==4:
                    rating_num="⭐"*4
                    print(f"Thanks🙏🙏 for sharing your {rating_num} rating with us.🤩🤩")

                elif rating==5:
                    rating_num="⭐"*5
                    print(f"Thanks🙏🙏 for sharing your {rating_num} rating with us.🤩🤩")

            else:
                print("Invalid Rating.Please provide rating out of 5")
                    



if __name__=="__main__":
    Restro=Restaurant()
    print("-"*30)
    print("  🍴😋 Indian Restaurant🍴😋")
    print("-"*30)
    while True:
        print('''             
        1)Show menu
        2)Order Item by id
        3)Order Item by name
        4)Search item by name
        5)Add Rating
        6)Exit''')
               
        print("-"*30)
        try:
            choice=int(input("What do you want try today: "))
        except ValueError as v:
            print(v)
        else:

            if choice==1:
                Restro.show_menu()
            elif choice==2:
                Restro.order_item_by_id()
    
            
            elif choice==3:
                
                Restro.order_item_by_name()

            elif choice==4:
                Restro.search_item_by_name()
            
            elif choice==5:
                Restro.add_rating()
            else:
                print("Thank you!")
                break
